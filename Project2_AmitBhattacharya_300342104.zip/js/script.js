const contact = document.querySelector(".contact-list");
let contactList = Array.from(contact.children);
console.log(contactList)
// console.log(contact[0].innerHTML);
// console.log(contact[0].getElementsByClassName("email")[0].outerText);
// console.log(contact[0].getElementsByClassName("avatar")[0]);
const itemsPerPage = 10;
var pageIndex=1;
const lengthOfList = contactList.length;
// let name = [];
// let email = [];
// let avatar = [];
// function extractData() {

//     name = [];
//     email = [];
//     avatar = [];
//     for (let i = 0; i < contact.length; i++) {
//         name[i] = contact[i].getElementsByTagName("h3")[0].outerText
//         email[i] = contact[i].getElementsByClassName("email")[0].outerText
//         avatar[i] = contact[0].getElementsByClassName("avatar")[0]
//     }
//     console.log(name)
//     console.log(email)
//     console.log(avatar)
// }

let paginationPane = document.getElementById("pagination");
var numOfPage = 0;

function displayList(list, pane, numberOfRows,pageNumber) {
    // console.log(contact[10].innerHTML)
    // extractData()
    pane.innerHTML = "";
    var lengthOfList = list.length;
    var numOfPage = Math.ceil(lengthOfList / numberOfRows);

    console.log(numOfPage)

    var startIndex = (pageNumber - 1) * numberOfRows;
    var endIndex = startIndex + numberOfRows;
    console.log(startIndex)
    console.log(endIndex)
    var c = 1;
    for (let i = startIndex; i < endIndex; i++) {
        var item = contactList[i];
        console.log(contactList[i]);
        console.log(i)
        pane.appendChild(item);
    }
}

function buttonCount(list, pane, numberOfRows){
    pane.innerHTML="";
    var pageCount = Math.ceil(lengthOfList / numberOfRows);
    for(let i=1; i<pageCount+1; i++){
        let btn = createButton(i, list);
        console.log(btn);
        pane.appendChild(btn);
    }
}

function createButton(page, array) {
    let btns = document.createElement('button');
    btns.innerText = page;

    btns.addEventListener('click', function(){
        pageIndex = page;
        displayList(array, contact, itemsPerPage, pageIndex);
    })

    console.log(btns)
    return btns;
}

function paginate(){
    
    displayList(contactList, contact, itemsPerPage, pageIndex);
    buttonCount(contactList, paginationPane, itemsPerPage);

}

paginate();